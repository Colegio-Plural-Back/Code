package com.treino.pedro.back.controllers; 

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity; 
import org.springframework.security.core.context.SecurityContextHolder; 
import org.springframework.web.bind.annotation.*; 

import com.treino.pedro.back.dtos.LoginRequestDTO; 
import com.treino.pedro.back.dtos.LoginResponseDTO; 
import com.treino.pedro.back.models.Usuario; 
import com.treino.pedro.back.services.UsuarioService; 

@RestController 
@RequestMapping("/usuario") 
public class UsuarioController { 

    @Autowired 
    private UsuarioService usuarioService; 

    @PostMapping("/cadastrar") 
    public ResponseEntity<String> cadastrarUsuario(@RequestBody Usuario usuario) { 
        usuarioService.cadastrar(usuario); 
        return ResponseEntity.status(HttpStatus.CREATED).body("Usuário cadastrado com sucesso"); 
    } 

    @PostMapping("/login") 
    public ResponseEntity<?> login(@RequestBody LoginRequestDTO request) { 
        try { 
            LoginResponseDTO response = usuarioService.login(request); 
            return ResponseEntity.ok(response); 
        } catch (Exception e) { 
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Falha na autenticação: e-mail ou senha inválidos"); 
        } 
    } 

    @PostMapping("/logout") 
    public ResponseEntity<String> logout() { 
        SecurityContextHolder.clearContext(); 
        return ResponseEntity.ok("Logout realizado com sucesso"); 
    } 

    @PutMapping("/atualizar/{id}") 
    public ResponseEntity<Usuario> atualizar(@RequestBody Usuario usuario, @PathVariable Integer id) { 
        Usuario usuarioAtualizado = usuarioService.atualizar(usuario, id); 
        return ResponseEntity.ok(usuarioAtualizado); 
    } 

    @DeleteMapping("/deletar/{id}") 
    public ResponseEntity<String> deletar(@PathVariable Integer id) { 
        usuarioService.deletar(id); 
        return ResponseEntity.ok("Usuário deletado com sucesso"); 
    } 

    @GetMapping("/buscar/{id}") 
    public ResponseEntity<Usuario> buscar(@PathVariable Integer id) { 
        Usuario usuario = usuarioService.buscar(id); 
        return ResponseEntity.ok(usuario); 
    } 

    @GetMapping("/listar") 
    public ResponseEntity<List<Usuario>> listarUsuarios() { 
        List<Usuario> usuarios = usuarioService.listarUsuarios(); 
        return ResponseEntity.ok(usuarios); 
    } 
}