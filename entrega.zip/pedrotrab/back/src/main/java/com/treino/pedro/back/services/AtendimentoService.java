package com.treino.pedro.back.services; 

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 

import com.treino.pedro.back.dtos.AtendimentoResponseDTO; 
import com.treino.pedro.back.models.Atendimento; 
import com.treino.pedro.back.repositories.AtendimentoRepository; 

@Service  
public class AtendimentoService { 

    @Autowired 
    private AtendimentoRepository atendimentoRepository; 

    @Autowired 
    private AlunoService alunoService; 

    @Autowired 
    private UsuarioService usuarioService; 

    public List<AtendimentoResponseDTO> listarAtendimentos() { 
        return atendimentoRepository.findAll().stream() 
                .map(atendimento -> new AtendimentoResponseDTO(
                        atendimento.getId(),
                        atendimento.getData(),
                        atendimento.getDescricao(),
                        atendimento.getAluno(),
                        atendimento.getUsuario()
                )) 
                .toList(); 
    } 

    public AtendimentoResponseDTO buscar(Integer id) { 
        Atendimento atendimento = buscarEntidade(id); 
        return new AtendimentoResponseDTO(
                atendimento.getId(),
                atendimento.getData(),
                atendimento.getDescricao(),
                atendimento.getAluno(),
                atendimento.getUsuario()
        ); 
    } 

    public Atendimento buscarEntidade(Integer id) {
        return atendimentoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Atendimento não encontrado com o ID: " + id));
    }

    public Atendimento cadastrar(Atendimento atendimento) { 
        if (atendimento.getAluno() != null && atendimento.getAluno().getId() != null) {
            atendimento.setAluno(alunoService.buscar(atendimento.getAluno().getId()));
        }
        if (atendimento.getUsuario() != null && atendimento.getUsuario().getId() != null) {
            atendimento.setUsuario(usuarioService.buscar(atendimento.getUsuario().getId()));
        }
        return atendimentoRepository.save(atendimento); 
    } 

    public Atendimento atualizar(Atendimento atendimento, Integer id) { 
        Atendimento atendimentoExistente = buscarEntidade(id); 

        if (atendimento.getData() != null) {
            atendimentoExistente.setData(atendimento.getData()); 
        }
        if (atendimento.getDescricao() != null) {
            atendimentoExistente.setDescricao(atendimento.getDescricao());
        }
        if (atendimento.getAluno() != null && atendimento.getAluno().getId() != null) {
            atendimentoExistente.setAluno(alunoService.buscar(atendimento.getAluno().getId())); 
        }
        if (atendimento.getUsuario() != null && atendimento.getUsuario().getId() != null) {
            atendimentoExistente.setUsuario(usuarioService.buscar(atendimento.getUsuario().getId())); 
        }

        return atendimentoRepository.save(atendimentoExistente); 
    } 

    public void deletar(Integer id) { 
        buscarEntidade(id); // Garante a validação antes de deletar
        atendimentoRepository.deleteById(id); 
    } 
}