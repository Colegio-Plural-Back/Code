package com.treino.pedro.back.services; 

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 

import com.treino.pedro.back.models.Aluno; 
import com.treino.pedro.back.repositories.AlunoRepository; 

@Service  
public class AlunoService { 

    @Autowired 
    private AlunoRepository alunoRepository; 

    @Autowired 
    private ResponsavelService responsavelService; 

    public Aluno cadastrar(Aluno aluno) { 
        if (aluno.getResponsavel() != null && aluno.getResponsavel().getId() != null) {
            aluno.setResponsavel(responsavelService.buscar(aluno.getResponsavel().getId())); 
        } else {
            throw new RuntimeException("É necessário informar um responsável válido para o aluno.");
        }
        return alunoRepository.save(aluno); 
    } 

    public Aluno atualizar(Aluno aluno, Integer id) { 
        Aluno alunoExistente = buscar(id); 

        if (aluno.getNome() != null) {
            alunoExistente.setNome(aluno.getNome()); 
        }
        if (aluno.getCpf() != null) {
            alunoExistente.setCpf(aluno.getCpf());
        }
        if (aluno.getResponsavel() != null && aluno.getResponsavel().getId() != null) {
            alunoExistente.setResponsavel(responsavelService.buscar(aluno.getResponsavel().getId())); 
        }

        return alunoRepository.save(alunoExistente); 
    } 

    public void deletar(Integer id) { 
        buscar(id); // Valida se o aluno existe antes de efetuar o delete
        alunoRepository.deleteById(id); 
    } 

    public Aluno buscar(Integer id) { 
        return alunoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Aluno não encontrado com o ID: " + id)); 
    } 

    public List<Aluno> listarAlunos() { 
        return alunoRepository.findAll(); 
    } 
}