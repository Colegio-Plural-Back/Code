package com.treino.pedro.back.dtos;

public class LoginResponseDTO { 
    private String nome; 
    private String cpf; 
    private String email; 
    private String token; 

    public LoginResponseDTO() {} 

    public LoginResponseDTO(String email, String nome, String cpf, String token) { 
        this.email = email; 
        this.nome = nome; 
        this.cpf = cpf; 
        this.token = token; 
    } 

    public String getNome() { return nome; } 
    public void setNome(String nome) { this.nome = nome; } 

    public String getCpf() { return cpf; } 
    public void setCpf(String cpf) { this.cpf = cpf; } 

    public String getEmail() { return email; } 
    public void setEmail(String email) { this.email = email; } 

    public String getToken() { return token; } 
    public void setToken(String token) { this.token = token; } 
}
