package com.treino.pedro.back.models;

import java.time.LocalDate; // Ajustado para bater com o tipo DATE do SQL

import jakarta.persistence.Column; 
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue; 
import jakarta.persistence.GenerationType; 
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table; 
 
@Entity  
@Table(name = "atendimento") 
public class Atendimento { 
 
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_atendimento")  
    private Integer id; 
 
    @Column(name = "data_atendimento", nullable = false) 
    private LocalDate data;

    @Column(name = "descricao_atendimento", nullable = false, columnDefinition = "TEXT")
    private String descricao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_aluno", nullable = false)
    private Aluno aluno;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", nullable = false) 
    private Usuario usuario;

    public Atendimento() {
    }

    public Atendimento(Integer id, LocalDate data, String descricao, Aluno aluno, Usuario usuario) {
        this.id = id;
        this.data = data;
        this.descricao = descricao;
        this.aluno = aluno;
        this.usuario = usuario;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public Aluno getAluno() { return aluno; }
    public void setAluno(Aluno aluno) { this.aluno = aluno; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
}