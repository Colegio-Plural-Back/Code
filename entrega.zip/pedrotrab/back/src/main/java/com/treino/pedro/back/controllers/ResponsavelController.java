package com.treino.pedro.back.controllers; 

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping; 
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.treino.pedro.back.models.Responsavel;
import com.treino.pedro.back.services.ResponsavelService; 

@RestController  
@RequestMapping("/responsavel") 
public class ResponsavelController { 

    @Autowired 
    private ResponsavelService responsavelService; 

    @PostMapping("/salvar") 
    public ResponseEntity<Responsavel> salvar(@RequestBody Responsavel responsavel) { 
        Responsavel responsavelSalvo = responsavelService.salvar(responsavel); 
        return ResponseEntity.status(HttpStatus.CREATED).body(responsavelSalvo); 
    } 

    @PutMapping("/atualizar/{id}") 
    public ResponseEntity<Responsavel> atualizar(@RequestBody Responsavel responsavel, @PathVariable Integer id) { 
        Responsavel responsavelAtualizado = responsavelService.atualizar(responsavel, id); 
        return ResponseEntity.ok(responsavelAtualizado); 
    } 

    @DeleteMapping("/deletar/{id}") 
    public ResponseEntity<String> deletar(@PathVariable Integer id) { 
        responsavelService.deletar(id); 
        return ResponseEntity.ok("Responsável deletado com sucesso"); 
    } 

    @GetMapping("/buscar/{id}") 
    public ResponseEntity<Responsavel> buscar(@PathVariable Integer id) { 
        Responsavel responsavel = responsavelService.buscar(id); 
        return ResponseEntity.ok(responsavel); 
    } 

    @GetMapping("/listar") 
    public ResponseEntity<List<Responsavel>> listarResponsaveis(
            @RequestParam(required = false) String termo) { 
        List<Responsavel> responsaveis = responsavelService.listarResponsaveis(termo); 
        return ResponseEntity.ok(responsaveis); 
    } 
}