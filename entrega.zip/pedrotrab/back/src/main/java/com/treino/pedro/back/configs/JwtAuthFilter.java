package com.treino.pedro.back.configs;

import java.io.IOException; 
import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; 
import org.springframework.security.core.authority.SimpleGrantedAuthority; 
import org.springframework.security.core.context.SecurityContextHolder; 
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource; 
import org.springframework.stereotype.Component; 
import org.springframework.web.filter.OncePerRequestFilter; 

import com.treino.pedro.back.repositories.UsuarioRepository; 

import jakarta.servlet.FilterChain; 
import jakarta.servlet.ServletException; 
import jakarta.servlet.http.HttpServletRequest; 
import jakarta.servlet.http.HttpServletResponse; 

@Component 
public class JwtAuthFilter extends OncePerRequestFilter { 

    @Autowired 
    private JwtService jwtService; 

    @Autowired 
    private UsuarioRepository usuarioRepository; 

    @Override 
    protected void doFilterInternal(HttpServletRequest request, 
                                    HttpServletResponse response, 
                                    FilterChain chain) 
            throws ServletException, IOException { 

        String header = request.getHeader("Authorization"); 

        if (header != null && header.startsWith("Bearer ")) { 
            String token = header.substring(7); 

            if (jwtService.isValid(token)) { 
                String email = jwtService.extractEmail(token); 

                usuarioRepository.findByEmail(email).ifPresent(user -> { 
                    var auth = new UsernamePasswordAuthenticationToken( 
                            user.getEmail(), 
                            null, 
                            List.of(new SimpleGrantedAuthority("ROLE_USER")) 
                    ); 

                    auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request)); 
                    SecurityContextHolder.getContext().setAuthentication(auth); 
                }); 
            } 
        } 

        chain.doFilter(request, response); 
    } 
}