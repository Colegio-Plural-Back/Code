package com.treino.pedro.back.controllers; 

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping; 
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.treino.pedro.back.dtos.AtendimentoResponseDTO;
import com.treino.pedro.back.models.Atendimento;
import com.treino.pedro.back.services.AtendimentoService; 

@RestController 
@RequestMapping("/atendimento") 
public class AtendimentoController { 

    @Autowired 
    private AtendimentoService atendimentoService; 

    @PostMapping("/cadastrar") 
    public ResponseEntity<String> cadastrarAtendimento(@RequestBody Atendimento atendimento) { 
        atendimentoService.cadastrar(atendimento); 
        return ResponseEntity.status(HttpStatus.CREATED).body("Atendimento cadastrado com sucesso"); 
    } 

    @PutMapping("/atualizar/{id}") 
    public ResponseEntity<String> atualizarAtendimento(@RequestBody Atendimento atendimento, @PathVariable Integer id) { 
        atendimentoService.atualizar(atendimento, id); 
        return ResponseEntity.ok("Atendimento atualizado com sucesso"); 
    } 

    @DeleteMapping("/deletar/{id}") 
    public ResponseEntity<String> deletarAtendimento(@PathVariable Integer id) { 
        atendimentoService.deletar(id); 
        return ResponseEntity.ok("Atendimento deletado com sucesso"); 
    } 

    @GetMapping("/buscar/{id}") 
    public ResponseEntity<AtendimentoResponseDTO> buscarAtendimento(@PathVariable Integer id) { 
        AtendimentoResponseDTO atendimento = atendimentoService.buscar(id); 
        return ResponseEntity.ok(atendimento); 
    } 

    @GetMapping("/listar") 
    public ResponseEntity<List<AtendimentoResponseDTO>> listarAtendimentos() { 
        List<AtendimentoResponseDTO> atendimentos = atendimentoService.listarAtendimentos(); 
        return ResponseEntity.ok(atendimentos); 
    } 
}