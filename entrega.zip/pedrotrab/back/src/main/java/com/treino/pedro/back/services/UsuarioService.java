package com.treino.pedro.back.services;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.security.authentication.AuthenticationManager; 
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; 
import org.springframework.security.crypto.password.PasswordEncoder; 
import org.springframework.stereotype.Service;


import com.treino.pedro.back.configs.JwtService;
import com.treino.pedro.back.dtos.LoginRequestDTO;
import com.treino.pedro.back.dtos.LoginResponseDTO;
import com.treino.pedro.back.models.Usuario; 
import com.treino.pedro.back.repositories.UsuarioRepository; 

@Service  
public class UsuarioService { 

    @Autowired private UsuarioRepository usuarioRepository; 
    @Autowired private JwtService jwtService; 
    @Autowired private AuthenticationManager authManager; 
    @Autowired private PasswordEncoder passwordEncoder; 

    public LoginResponseDTO login(LoginRequestDTO usuario) { 
        authManager.authenticate(
            new UsernamePasswordAuthenticationToken(usuario.getEmail(), usuario.getSenha())
        ); 

        Usuario usuarioRetornado = usuarioRepository.findByEmail(usuario.getEmail())
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado.")); 

        // Gera o token apenas com o e-mail do usuário (ou passando o CPF se seu JwtService exigir)
        String token = jwtService.generateToken(usuarioRetornado.getEmail()); 

        return new LoginResponseDTO(
            usuarioRetornado.getEmail(), 
            usuarioRetornado.getNome(), 
            usuarioRetornado.getCpf(), 
            token
        ); 
    } 

    public Usuario cadastrar(Usuario usuario) { 
        usuario.setSenha(passwordEncoder.encode(usuario.getSenha())); 
        return usuarioRepository.save(usuario); 
    } 

    public Usuario atualizar(Usuario usuario, Integer id) { 
        Usuario usuarioExistente = buscar(id); 

        if (usuario.getNome() != null) usuarioExistente.setNome(usuario.getNome()); 
        if (usuario.getEmail() != null) usuarioExistente.setEmail(usuario.getEmail()); 
        if (usuario.getSenha() != null && !usuario.getSenha().isBlank()) {
            usuarioExistente.setSenha(passwordEncoder.encode(usuario.getSenha())); 
        }
        if (usuario.getCpf() != null) usuarioExistente.setCpf(usuario.getCpf());
        
        return usuarioRepository.save(usuarioExistente); 
    } 

    public void deletar(Integer id) { 
        buscar(id); 
        usuarioRepository.deleteById(id); 
    } 

    public Usuario buscar(Integer id) { 
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado com o ID: " + id)); 
    } 

    public List<Usuario> listarUsuarios() { 
        return usuarioRepository.findAll(); 
    } 
}