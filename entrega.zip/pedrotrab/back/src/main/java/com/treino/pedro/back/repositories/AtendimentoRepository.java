package com.treino.pedro.back.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.treino.pedro.back.models.Atendimento;

public interface AtendimentoRepository extends JpaRepository<Atendimento, Integer>{ 
    @Query(value = "SELECT at.* FROM atendimento at " +
               "INNER JOIN aluno al ON al.id_aluno = at.id_aluno " +
               "INNER JOIN responsavel r ON r.id_responsavel = al.id_responsavel " +
               "ORDER BY at.data_atendimento ASC", 
       nativeQuery = true)
List<Atendimento> listarAtendimentos();
}