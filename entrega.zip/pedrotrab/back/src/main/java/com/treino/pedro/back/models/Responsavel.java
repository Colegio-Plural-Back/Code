package com.treino.pedro.back.models;

import jakarta.persistence.Column; 
import jakarta.persistence.Entity; 
import jakarta.persistence.GeneratedValue; 
import jakarta.persistence.GenerationType; 
import jakarta.persistence.Id; 
import jakarta.persistence.Table; 
 
@Entity  
@Table(name = "responsavel") 
public class Responsavel { 
 
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name = "id_responsavel")
    private Integer id; 
 
    @Column(name = "nome_responsavel", nullable = false) 
    private String nome;

    @Column(name = "email_responsavel", nullable = false, unique = true)
    private String email;

    @Column(name = "cpf_responsavel", nullable = false, unique = true)
    private String cpf;

    public Responsavel() {
    }

    public Responsavel(Integer id, String nome, String email, String cpf) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.cpf = cpf;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }
}