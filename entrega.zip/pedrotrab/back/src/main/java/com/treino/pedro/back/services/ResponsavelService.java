package com.treino.pedro.back.services;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 

import com.treino.pedro.back.models.Responsavel; 
import com.treino.pedro.back.repositories.ResponsavelRepository; 

@Service  
public class ResponsavelService { 

    @Autowired 
    private ResponsavelRepository responsavelRepository; 

    public List<Responsavel> listarResponsaveis(String termo) { 
        if (termo != null && !termo.isBlank()) {
            return responsavelRepository.listarResponsaveis(termo); 
        }
        return responsavelRepository.findAll();
    } 

    public Responsavel buscar(Integer id) { 
        return responsavelRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Responsável não encontrado com o ID: " + id)); 
    } 

    public Responsavel salvar(Responsavel responsavel) { 
        // CPF salvo em texto limpo/formatado para permitir busca e exibição na interface
        return responsavelRepository.save(responsavel); 
    } 

    public Responsavel atualizar(Responsavel responsavel, Integer id) { 
        Responsavel responsavelExistente = buscar(id); 

        if (responsavel.getNome() != null) {
            responsavelExistente.setNome(responsavel.getNome()); 
        }
        if (responsavel.getEmail() != null) {
            responsavelExistente.setEmail(responsavel.getEmail());
        }
        if (responsavel.getCpf() != null) {
            responsavelExistente.setCpf(responsavel.getCpf()); 
        }

        return responsavelRepository.save(responsavelExistente); 
    } 

    public void deletar(Integer id) { 
        buscar(id); // Valida existência antes de remover
        responsavelRepository.deleteById(id); 
    } 
}
