package com.treino.pedro.back.repositories;

import java.util.Optional; 

import org.springframework.data.jpa.repository.JpaRepository; 

import com.treino.pedro.back.models.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Integer>{ 
   
}
