package com.treino.pedro.back.dtos; 

import java.time.LocalDate; 
import com.treino.pedro.back.models.Aluno; 
import com.treino.pedro.back.models.Usuario; 

public class AtendimentoResponseDTO { 

    private Integer id; 
    private LocalDate data; 
    private String descricao; 
    private Aluno aluno; 
    private Usuario usuario; 

    public AtendimentoResponseDTO() {} 

    public AtendimentoResponseDTO(Integer id, LocalDate data, String descricao, Aluno aluno, Usuario usuario) { 
        this.id = id; 
        this.data = data; 
        this.descricao = descricao; 
        this.aluno = aluno; 
        this.usuario = usuario; 
    } 

    public Integer getId() { 
        return id; 
    } 

    public void setId(Integer id) { 
        this.id = id; 
    } 

    public LocalDate getData() { 
        return data; 
    } 

    public void setData(LocalDate data) { 
        this.data = data; 
    } 

    public String getDescricao() { 
        return descricao; 
    } 

    public void setDescricao(String descricao) { 
        this.descricao = descricao; 
    } 

    public Aluno getAluno() { 
        return aluno; 
    } 

    public void setAluno(Aluno aluno) { 
        this.aluno = aluno; 
    } 

    public Usuario getUsuario() { 
        return usuario; 
    } 

    public void setUsuario(Usuario usuario) { 
        this.usuario = usuario; 
    } 
}