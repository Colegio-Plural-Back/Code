package com.treino.pedro.back.repositories;

import java.util.Optional; 

import org.springframework.data.jpa.repository.JpaRepository; 

import com.treino.pedro.back.models.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer>{ 
Optional<Usuario> findByEmail(String email); 
}
